from lexer import lexer

class parser():
    def __init__(self, tokens):
        self.tokens = tokens
        self.current = 0

    # verifica se ci sono ancora token da analizzare, restituisce il token senza avanzare
    def peek(self):
        if self.current < len(self.tokens):
            return self.tokens[self.current]
        return None

    # Avanza al prossimo token e lo restituisce, se disponibile
    def advance(self):
        tok = self.peek()
        if tok:
            self.current += 1
        return tok

    # Si aspetta un token di un certo tipo, altrimenti lancia un errore
    def expect(self, type_):
        tok = self.advance()
        if tok is None or tok[0] != type_:
            raise self.error(f"Expected {type_}, got {tok}", tok)
        return tok

    # Analizza un singolo statement in base al tipo del prossimo token
    def parse(self):
        # Funzione principale che processa tutti gli statement fino alla fine del codice
        statements = []
        while self.peek() is not None:
            stmt = self.statement()
            if stmt:
                statements.append(stmt)
        return statements

    # Gestisce gli statement in base al tipo del prossimo token
    def statement(self):
        tok = self.peek()

        if tok is None:
            return None
        elif tok[0] in ("TYPE_INT", "TYPE_FLOAT", "TYPE_STRING", "TYPE_BOOL"):
            if (self.current + 2 < len(self.tokens) and
                    self.tokens[self.current + 1][0] == "ID" and
                    self.tokens[self.current + 2][0] == "LPAREN"):
                return self.function_definition()
            else:
                return self.declaration()
        elif tok[0] == "ID":
            return self.assignment_or_funcall()
        elif tok[0] == "IF":
            return self.if_statement()
        elif tok[0] == "WHILE":
            return self.while_statement()
        elif tok[0] == "COUT":
            return self.cout_statement()
        elif tok[0] == "CIN":
            return self.cin_statement()
        elif tok[0] == "FUNCTION":
            return self.function_definition()
        elif tok[0] == "RETURN":
            self.advance()
            expr = self.logic()
            self.expect("SEMICOLON")
            return ("return", expr)
        else:
            self.error(f"Unexpected token {tok}", tok)

    def function_definition(self):
        return_type = self.advance()[0]  # es: TYPE_INT
        name = self.expect("ID")[1]
        self.expect("LPAREN")
        params = []
        if self.peek()[0] != "RPAREN":
            while True:
                param_type = self.advance()[0]
                param_name = self.expect("ID")[1]
                params.append((param_type, param_name))
                if self.peek() and self.peek()[0] == "COMMA":
                    self.advance()
                else:
                    break
        self.expect("RPAREN")
        self.expect("LBRACE")
        body = []
        while self.peek() and self.peek()[0] != "RBRACE":
            stmt = self.statement()
            if stmt:
                body.append(stmt)
        self.expect("RBRACE")
        return ("function", return_type, name, params, body)

    # Gestisce le assegnazioni o le chiamate di funzione
    def factor(self):
        # Gestisce i fattori, che possono essere numeri, variabili o espressioni tra parentesi
        tok = self.peek()

        if tok is None:
            self.error("Unexpected end of input", tok)
        elif tok[0] == "ID":
            # Controlla se è una chiamata di funzione
            if (self.current + 1 < len(self.tokens) and
                    self.tokens[self.current + 1][0] == "LPAREN"):
                name = self.advance()[1]
                self.expect("LPAREN")
                args = []
                if self.peek()[0] != "RPAREN":
                    while True:
                        args.append(self.logic())
                        if self.peek() and self.peek()[0] == "COMMA":
                            self.advance()
                        else:
                            break
                self.expect("RPAREN")
                return ("call", name, args)
            else:
                self.advance()
                return ("var", tok[1])
        elif tok[0] in ("INT", "FLOAT", "STRING"):
            self.advance()
            return (tok[0].lower(), tok[1])
        elif tok[0] == "BOOL":
            self.advance()
            return ("bool", tok[1])
        elif tok[0] == "MINUS":
            self.advance()
            expr = self.factor()
            return ("minus", expr)
        elif tok[0] == "LPAREN":
            self.advance()
            expr = self.comparison()
            self.expect("RPAREN")
            return expr
        elif tok[0] == "NOT":
            self.advance()
            expr = self.factor()
            return ("not", expr)
        else:
            self.error(f"Unexpected token {tok}", tok)

    # Gestisce le espressioni aritmetiche, es: 5 + 3 * 2
    def term(self):
        left = self.factor()
        while self.peek() and self.peek()[0] in ("TIMES", "DIVIDE", "MODULE"):
            op = self.advance()[0]
            right = self.factor()
            left = (op, left, right)
        return left

    # Gestisce le espressioni additive, es: x + 5 - 3
    def additive(self):
        left = self.term()
        while self.peek() and self.peek()[0] in ("PLUS", "MINUS"):
            op = self.advance()[0]
            right = self.term()
            left = (op, left, right)
        return left

    def logic(self):
        left = self.comparison()
        while self.peek() and self.peek()[0] in ("AND", "OR"):
            op = self.advance()[0]
            right = self.comparison()
            left = (op, left, right)
        return left

    # Gestisce le espressioni di confronto, es: x == 5, x < 10
    def comparison(self):
        left = self.additive()
        while self.peek() and self.peek()[0] in ("LT", "GT", "EQ", "LE", "GE"):
            op = self.advance()[0]
            right = self.additive()
            left = (op, left, right)
        return left

    # Gestisce dichiarazione variabili, es: int x = 5;
    def declaration(self):
        type_ = self.advance()[0]
        name = self.expect("ID")[1]
        expr = None
        tok = self.peek()

        if tok and tok[0] == "ASSIGN":
            self.advance()
            expr = self.logic()

        self.expect("SEMICOLON")
        return ("declare", type_, name, expr)

    def if_statement(self):
        self.expect("IF")
        self.expect("LPAREN")
        condition = self.logic()
        self.expect("RPAREN")
        self.expect("LBRACE")

        body = []
        while self.peek() and self.peek()[0] != "RBRACE":
            stmt = self.statement()
            if stmt:
                body.append(stmt)
        self.expect("RBRACE")

        else_body = []
        if self.peek() and self.peek()[0] == "ELSE":
            self.advance()
            if self.peek() and self.peek()[0] == "IF":
                else_body.append(self.if_statement())
            else:
                self.expect("LBRACE")
                while self.peek() and self.peek()[0] != "RBRACE":
                    stmt = self.statement()
                    if stmt:
                        else_body.append(stmt)
                self.expect("RBRACE")
        return ("if", condition, body, else_body)

    def while_statement(self):
        self.expect("WHILE")
        self.expect("LPAREN")
        condition = self.logic()
        self.expect("RPAREN")
        self.expect("LBRACE")
        body = []
        while self.peek() and self.peek()[0] != "RBRACE":
            stmt = self.statement()
            if stmt:
                body.append(stmt)
        self.expect("RBRACE")

        return ("while", condition, body)

    def assignment_or_funcall(self):
        name = self.expect("ID")[1]
        tok = self.peek()

        if tok and tok[0] == "ASSIGN":
            self.advance()
            expr = self.logic()
            self.expect("SEMICOLON")
            return ("assign", name, expr)
        elif tok and tok[0] == "INCREMENT":
            self.advance()
            self.expect("SEMICOLON")
            return ("increment", name)
        elif tok and tok[0] == "DECREMENT":
            self.advance()
            self.expect("SEMICOLON")
            return ("decrement", name)
        else:
            self.error("Invalid statement after identifier", tok)

    def cout_statement(self):
        self.expect("COUT")
        self.expect("LSHIFT")
        expr = self.comparison()
        if expr[0] == "STRING":
            expr = ("string", expr[1])
        while self.peek() and self.peek()[0] == "LSHIFT":
            self.advance()
            if self.peek()[0] == "ENDL":
                self.advance()
                expr = ("concat", expr, ("string", "\n"))
            else:
                next_expr = self.comparison()
                if next_expr[0] == "STRING":
                    next_expr = ("string", next_expr[1])

                expr = ("concat", expr, next_expr)

        if self.peek() and self.peek()[0] == "SEMICOLON":
            self.advance()
        else:
            self.error("Expected SEMICOLON after cout statement", self.peek())
        return ("cout", expr)

    def cin_statement(self):
        self.expect("CIN")
        self.expect("RSHIFT")
        var = self.expect("ID")[1]
        if self.peek() and self.peek()[0] == "SEMICOLON":
            self.advance()
        else:
            self.error("Expected SEMICOLON after cin statement", self.peek())
        return ("cin", var)

    # Gestisce errori di sintassi, indicando la linea in cui si è verificato
    def error(self, message, token):
        line = token[2] if token else "unknown"
        raise SyntaxError(f"{message} at line {line}")


if __name__ == "__main__":
    code = '''
    int counter = 0;
    int x;
    
    while (counter < 18) {
        if (counter % 2 == 0) {
            cout << "Counter is even: " << counter << endl;
        } else {
            cout << "Counter is odd: " << counter << endl;
            cin >> x;
        }
        counter++;
    }
    '''

    tokens = lexer(code)
    parser_instance = parser(tokens)
    ast = parser_instance.parse()

    from pprint import pprint
    pprint(ast)