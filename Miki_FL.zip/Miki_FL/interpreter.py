class interpreter:
    def __init__(self, ast):
        self.ast = ast
        self.env = {}
        self.functions = {}

    def execute(self, node):
        match node:
            case ('declare', type_, name, expr):
                if name in self.env:
                    raise self.error(f"Variable '{name}' already declared", node[2])
                value = self.eval_expr(expr) if expr else None
                self.env[name] = (type_, value)

            case ('assign', name, expr):
                if name not in self.env:
                    raise self.error(f"Variable '{name}' not declared", node[2])
                value = self.eval_expr(expr)
                type_ = self.env[name][0]
                self.env[name] = (type_, value)

            case ('if', condition, body, else_body):
                cond_value = self.eval_expr(condition)
                if cond_value:
                    for stmt in body:
                        self.execute(stmt)
                else:
                    for stmt in else_body:
                        self.execute(stmt)

            case ('while', condition, body):
                while self.eval_expr(condition):
                    for stmt in body:
                        self.execute(stmt)

            case ('increment', name):
                if name not in self.env:
                    raise self.error(f"Variable '{name}' not declared", node[2])
                type_, value = self.env[name]
                self.env[name] = (type_, value + 1 if type_ == 'TYPE_INT' else value + 1.0)

            case ('decrement', name):
                if name not in self.env:
                    raise self.error(f"Variable '{name}' not declared", node[2])
                type_, value = self.env[name]
                self.env[name] = (type_, value - 1 if type_ == 'TYPE_INT' else value - 1.0)

            case ('cout', expr):
                output = self.eval_expr(expr)
                if output is not None:
                    print(output, end="")

            case ('cin', name):
                if name not in self.env:
                    raise self.error(f"Variable '{name}' not declared", node[2])
                value = input()
                type_ = self.env[name][0]
                if type_ == 'TYPE_INT':
                    self.env[name] = ('TYPE_INT', int(value))
                elif type_ == 'TYPE_FLOAT':
                    self.env[name] = ('TYPE_FLOAT', float(value))
                elif type_ == 'TYPE_STRING':
                    self.env[name] = ('TYPE_STRING', value)
                else:
                    raise self.error(f"Unsupported type '{type_}' for variable '{name}'", node[2])

            case ('function', return_type, name, params, body):
                self.functions[name] = (return_type, params, body)

            case ('call', name, args):
                if name not in self.functions:
                    raise RuntimeError(f"Function '{name}' not declared")
                return_type, params, body = self.functions[name]
                local_env = self.env.copy()
                for (ptype, pname), arg in zip(params, args):
                    local_env[pname] = (ptype, self.eval_expr(arg))
                return self.execute_function_body(body, local_env)

            case ('return', expr):
                value = self.eval_expr(expr)
                raise ReturnValue(value)

            case _:
                raise self.error(f"Unknown AST node: {node}")

    def execute_function_body(self, body, local_env):
        try:
            old_env = self.env
            self.env = local_env
            for stmt in body:
                result = self.execute(stmt)
        except ReturnValue as rv:
            self.env = rv.value
            return rv.value
        self.env = old_env
        return None

    class ReturnValue(Exception):
        def __init__(self, value):
            self.value = value


    def eval_expr(self, expr):
        match expr:
            case ('int', value):
                return int(value)

            case ('float', value):
                return float(value)

            case ('string', value):
                return value

            case ('concat', expr, next_expr):
                return str(self.eval_expr(expr)) + str(self.eval_expr(next_expr))

            case ('not', inner):
                return not self.eval_expr(inner)

            case ('minus', inner):
                return -self.eval_expr(inner)

            case ('bool', value):
                return value.lower() == 'true'

            case (op, left, right):
                l = self.eval_expr(left)
                r = self.eval_expr(right)
                match op:
                    case 'PLUS': return l + r
                    case 'MINUS': return l - r
                    case 'TIMES': return l * r
                    case 'DIVIDE': return l / r
                    case 'EQ': return l == r
                    case 'NEQ': return l != r
                    case 'LT': return l < r
                    case 'GT': return l > r
                    case 'LE': return l <= r
                    case 'GE': return l >= r
                    case 'AND': return l and r
                    case 'OR': return l or r
                    case 'MODULE': return l % r
                raise self.error(f"Unknown operator '{op}' in the expression {expr}")

            case ('var', name):
                if name not in self.env:
                    raise self.error(f"Variable '{name}' not declared")
                return self.env[name][1]

            case _:
                raise self.error(f"Unknown expression type: {expr}")

    def run(self):
        for smt in self.ast:
            self.execute(smt)

    def error(self, message, token=None):
        if token:
            raise RuntimeError(f"{message} at line {token[2]}")
        else:
            raise RuntimeError(message)

if __name__ == '__main__':
    from lexer import lexer
    from parser import parser
    from semantic_analyzer import SemanticAnalyzer

    code='''
    
    int somma(int a, int b) {
        return a + b;
    }
    
    int i = 0;
    int j = 0;
    int outer_limit = 1000;
    int inner_limit = 1000;
    int somma_result = somma(5, 10);
    
    cout << "Value: " << somma_result << endl;
    
    while (i < outer_limit) {
        j = 0;
        while (j < inner_limit) {
            if ((i + j) % 2 == 0) {
                cout << "Even sum: " << (i + j) << endl;
            } else {
                cout << "Odd sum: " << (i + j) << endl;
            }
            j++;
        }
        i++;
    }
    '''

    tokens = lexer(code)

    parser_instance = parser(tokens)
    ast = parser_instance.parse()

    semantic_analyzer_instance = SemanticAnalyzer(ast)
    semantic_analyzer_instance.analyze()

    interpreter_instance = interpreter(ast)
    interpreter_instance.run()